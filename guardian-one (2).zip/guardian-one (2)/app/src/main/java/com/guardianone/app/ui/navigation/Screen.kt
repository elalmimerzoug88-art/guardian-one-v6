package com.guardianone.app.ui.navigation

sealed class Screen(val route: String, val title: String) {
    object Home : Screen("home", "Guardian Hub")
    object Camera : Screen("camera", "Camera Feed")
    object Videos : Screen("videos", "Recordings")
    object Events : Screen("events", "Event Logs")
    object Settings : Screen("settings", "System Settings")
}
