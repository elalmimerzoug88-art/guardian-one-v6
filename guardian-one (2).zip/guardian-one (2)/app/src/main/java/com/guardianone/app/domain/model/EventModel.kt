package com.guardianone.app.domain.model

data class EventModel(
    val id: Long = 0,
    val title: String,
    val description: String,
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "INFO"
)
