package com.guardianone.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import androidx.camera.core.CameraSelector
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.guardianone.app.MainActivity
import com.guardianone.app.camera.CameraManager
import com.guardianone.app.camera.MotionAnalyzer
import com.guardianone.app.camera.VideoRecorder
import com.guardianone.app.data.repository.MotionSettingsRepository
import com.guardianone.app.domain.model.VideoModel
import com.guardianone.app.domain.usecase.AddEventUseCase
import com.guardianone.app.domain.usecase.AddVideoUseCase
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import kotlin.math.max

@AndroidEntryPoint
class MonitoringService : LifecycleService() {

    @Inject
    lateinit var addEventUseCase: AddEventUseCase

    @Inject
    lateinit var addVideoUseCase: AddVideoUseCase

    @Inject
    lateinit var motionSettingsRepository: MotionSettingsRepository

    private val cameraManager = CameraManager()
    private val videoRecorder = VideoRecorder()

    private var autoStopJob: Job? = null
    private var lastLoggedTime = 0L
    private var currentPeakMotion = 0f

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_BATTERY_LOW) {
                val settings = motionSettingsRepository.settings.value
                if (settings.stopOnLowBattery) {
                    lifecycleScope.launch {
                        addEventUseCase(
                            title = "Monitoring Stopped",
                            description = "Foreground monitoring service stopped automatically due to low battery.",
                            status = "WARNING"
                        )
                        stopMonitoringService()
                    }
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        _isServiceRunning.value = true
        createNotificationChannel()

        val filter = IntentFilter(Intent.ACTION_BATTERY_LOW)
        registerReceiver(batteryReceiver, filter)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)

        when (intent?.action) {
            ACTION_STOP_SERVICE -> {
                stopMonitoringService()
                return START_NOT_STICKY
            }
            ACTION_START_SERVICE, null -> {
                startForegroundWithNotification()
                initializeCameraAndMotion()
            }
        }

        return START_STICKY
    }

    private fun startForegroundWithNotification() {
        val notification = buildNotification(
            motionPct = _currentMotionPct.value,
            isRecording = _isRecordingState.value
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            var serviceType = ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                serviceType = serviceType or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            }
            startForeground(NOTIFICATION_ID, notification, serviceType)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun initializeCameraAndMotion() {
        val analyzer = MotionAnalyzer(lifecycleScope) { percentage, state ->
            _currentMotionPct.value = percentage

            val settings = motionSettingsRepository.settings.value
            val threshold = settings.activeThreshold
            val autoStopDelay = settings.autoStopDelaySeconds
            val currentTime = System.currentTimeMillis()

            if (percentage >= threshold) {
                currentPeakMotion = max(currentPeakMotion, percentage)

                autoStopJob?.cancel()
                autoStopJob = null

                if (currentTime - lastLoggedTime > 3000) {
                    lastLoggedTime = currentTime
                    lifecycleScope.launch {
                        addEventUseCase(
                            title = "Background Motion Detected",
                            description = "Motion level ${percentage.toInt()}% reached threshold (${threshold.toInt()}%). State: ${state.label}",
                            status = "WARNING"
                        )
                    }
                }

                if (!videoRecorder.isRecording) {
                    val vCapture = cameraManager.videoCapture
                    if (vCapture != null) {
                        _isRecordingState.value = true
                        updateNotification()

                        lifecycleScope.launch {
                            addEventUseCase(
                                title = "Auto Recording (Background)",
                                description = "Automatic video recording initiated in background monitoring service.",
                                status = "WARNING"
                            )
                        }

                        videoRecorder.startRecording(
                            context = this@MonitoringService,
                            videoCapture = vCapture,
                            initialPeakMotion = percentage,
                            onStarted = {
                                _isRecordingState.value = true
                                updateNotification()
                            },
                            onFinished = { filePath, fileName, duration, sizeBytes ->
                                _isRecordingState.value = false
                                updateNotification()

                                lifecycleScope.launch {
                                    addVideoUseCase(
                                        VideoModel(
                                            fileName = fileName,
                                            filePath = filePath,
                                            fileSizeBytes = sizeBytes,
                                            durationSeconds = duration,
                                            startTimeMs = videoRecorder.currentRecordingStartTimeMs,
                                            endTimeMs = System.currentTimeMillis(),
                                            peakMotionPercentage = currentPeakMotion,
                                            isAutoRecorded = true
                                        )
                                    )
                                    addEventUseCase(
                                        title = "Video Saved (Background)",
                                        description = "Background recording saved: $fileName ($duration s)",
                                        status = "SUCCESS"
                                    )
                                    currentPeakMotion = 0f
                                }
                            },
                            onError = { err ->
                                _isRecordingState.value = false
                                updateNotification()
                                lifecycleScope.launch {
                                    addEventUseCase(
                                        title = "Recording Error (Background)",
                                        description = err,
                                        status = "ERROR"
                                    )
                                }
                            }
                        )
                    }
                }
            } else {
                if (videoRecorder.isRecording && autoStopJob == null) {
                    autoStopJob = lifecycleScope.launch {
                        delay(autoStopDelay * 1000L)
                        videoRecorder.stopRecording()
                    }
                }
            }

            updateNotification()
        }

        cameraManager.startCamera(
            context = this,
            lifecycleOwner = this,
            previewView = null,
            lensFacing = CameraSelector.LENS_FACING_BACK,
            motionAnalyzer = analyzer,
            onError = { exc ->
                lifecycleScope.launch {
                    addEventUseCase(
                        title = "Camera Error (Service)",
                        description = exc.localizedMessage ?: "Camera failed in background service",
                        status = "ERROR"
                    )
                }
            }
        )

        lifecycleScope.launch {
            addEventUseCase(
                title = "Background Monitoring Started",
                description = "Guardian One background foreground monitoring engine active.",
                status = "ACTIVE"
            )
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Guardian One Monitoring",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Ongoing camera motion analysis and auto-recording background monitoring"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(motionPct: Float, isRecording: Boolean): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, MonitoringService::class.java).apply {
            action = ACTION_STOP_SERVICE
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val recordingText = if (isRecording) "نشط 🔴" else "متوقف 🟢"
        val contentText = "المراقبة: نشطة | الحركة: ${motionPct.toInt()}% | التسجيل: $recordingText"

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Guardian One يعمل")
            .setContentText(contentText)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setOngoing(true)
            .setContentIntent(openAppPendingIntent)
            .addAction(
                android.R.drawable.ic_media_pause,
                "إيقاف المراقبة",
                stopPendingIntent
            )
            .addAction(
                android.R.drawable.ic_menu_view,
                "فتح التطبيق",
                openAppPendingIntent
            )
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun updateNotification() {
        val notification = buildNotification(
            motionPct = _currentMotionPct.value,
            isRecording = _isRecordingState.value
        )
        val manager = getSystemService(NotificationManager::class.java)
        manager?.notify(NOTIFICATION_ID, notification)
    }

    private fun stopMonitoringService() {
        try {
            unregisterReceiver(batteryReceiver)
        } catch (e: Exception) {
            // ignore
        }
        videoRecorder.stopRecording()
        cameraManager.stopCamera()
        _isServiceRunning.value = false
        _isRecordingState.value = false
        _currentMotionPct.value = 0f
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopMonitoringService()
        super.onDestroy()
    }

    companion object {
        const val CHANNEL_ID = "guardian_one_monitoring_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START_SERVICE = "com.guardianone.app.action.START_MONITORING"
        const val ACTION_STOP_SERVICE = "com.guardianone.app.action.STOP_MONITORING"

        private val _isServiceRunning = MutableStateFlow(false)
        val isServiceRunning: StateFlow<Boolean> = _isServiceRunning.asStateFlow()

        private val _isRecordingState = MutableStateFlow(false)
        val isRecordingState: StateFlow<Boolean> = _isRecordingState.asStateFlow()

        private val _currentMotionPct = MutableStateFlow(0f)
        val currentMotionPct: StateFlow<Float> = _currentMotionPct.asStateFlow()

        fun start(context: Context) {
            val intent = Intent(context, MonitoringService::class.java).apply {
                action = ACTION_START_SERVICE
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, MonitoringService::class.java).apply {
                action = ACTION_STOP_SERVICE
            }
            context.startService(intent)
        }
    }
}
