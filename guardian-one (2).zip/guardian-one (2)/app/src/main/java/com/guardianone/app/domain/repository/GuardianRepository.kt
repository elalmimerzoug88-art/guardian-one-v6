package com.guardianone.app.domain.repository

import com.guardianone.app.domain.model.EventModel
import com.guardianone.app.domain.model.VideoModel
import kotlinx.coroutines.flow.Flow

interface GuardianRepository {
    fun getAllEvents(): Flow<List<EventModel>>
    suspend fun insertEvent(event: EventModel)
    suspend fun deleteEvent(event: EventModel)

    fun getAllVideos(): Flow<List<VideoModel>>
    suspend fun insertVideo(video: VideoModel): Long
    suspend fun deleteVideo(video: VideoModel)
    suspend fun deleteVideoById(id: Long)
}
