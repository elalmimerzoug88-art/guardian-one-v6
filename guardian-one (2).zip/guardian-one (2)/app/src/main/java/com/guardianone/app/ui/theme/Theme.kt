package com.guardianone.app.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = AccentBlue,
    onPrimary = Zinc200,
    primaryContainer = Zinc900,
    onPrimaryContainer = Zinc200,
    secondary = Zinc700,
    onSecondary = Zinc200,
    tertiary = AccentGreen,
    background = Zinc950,
    onBackground = Zinc200,
    surface = Zinc900,
    onSurface = Zinc200,
    surfaceVariant = Zinc800,
    onSurfaceVariant = Zinc400
)

private val LightColorScheme = DarkColorScheme // Default to Elegant Dark theme across both modes


@Composable
fun GuardianOneTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
