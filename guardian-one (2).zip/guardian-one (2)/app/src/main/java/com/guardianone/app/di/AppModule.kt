package com.guardianone.app.di

import com.guardianone.app.data.repository.GuardianRepositoryImpl
import com.guardianone.app.domain.repository.GuardianRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class AppModule {

    @Binds
    @Singleton
    abstract fun bindGuardianRepository(
        guardianRepositoryImpl: GuardianRepositoryImpl
    ): GuardianRepository
}
