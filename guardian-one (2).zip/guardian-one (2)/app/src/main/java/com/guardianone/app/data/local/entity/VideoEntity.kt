package com.guardianone.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.guardianone.app.domain.model.VideoModel

@Entity(tableName = "videos")
data class VideoEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val fileName: String,
    val filePath: String,
    val fileSizeBytes: Long,
    val durationSeconds: Long,
    val startTimeMs: Long,
    val endTimeMs: Long,
    val peakMotionPercentage: Float,
    val isAutoRecorded: Boolean
)

fun VideoEntity.toDomain(): VideoModel = VideoModel(
    id = id,
    fileName = fileName,
    filePath = filePath,
    fileSizeBytes = fileSizeBytes,
    durationSeconds = durationSeconds,
    startTimeMs = startTimeMs,
    endTimeMs = endTimeMs,
    peakMotionPercentage = peakMotionPercentage,
    isAutoRecorded = isAutoRecorded
)

fun VideoModel.toEntity(): VideoEntity = VideoEntity(
    id = id,
    fileName = fileName,
    filePath = filePath,
    fileSizeBytes = fileSizeBytes,
    durationSeconds = durationSeconds,
    startTimeMs = startTimeMs,
    endTimeMs = endTimeMs,
    peakMotionPercentage = peakMotionPercentage,
    isAutoRecorded = isAutoRecorded
)
