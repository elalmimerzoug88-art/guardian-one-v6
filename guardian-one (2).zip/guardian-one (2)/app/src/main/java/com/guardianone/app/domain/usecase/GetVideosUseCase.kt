package com.guardianone.app.domain.usecase

import com.guardianone.app.domain.model.VideoModel
import com.guardianone.app.domain.repository.GuardianRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class GetVideosUseCase @Inject constructor(
    private val repository: GuardianRepository
) {
    operator fun invoke(): Flow<List<VideoModel>> {
        return repository.getAllVideos()
    }
}
