package com.guardianone.app.di

import android.content.Context
import androidx.room.Room
import com.guardianone.app.data.local.GuardianDatabase
import com.guardianone.app.data.local.dao.EventDao
import com.guardianone.app.data.local.dao.VideoDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideGuardianDatabase(
        @ApplicationContext context: Context
    ): GuardianDatabase {
        return Room.databaseBuilder(
            context,
            GuardianDatabase::class.java,
            "guardian_one.db"
        ).fallbackToDestructiveMigration().build()
    }

    @Provides
    @Singleton
    fun provideEventDao(database: GuardianDatabase): EventDao {
        return database.eventDao()
    }

    @Provides
    @Singleton
    fun provideVideoDao(database: GuardianDatabase): VideoDao {
        return database.videoDao()
    }
}
